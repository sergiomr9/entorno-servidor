<?php 

    namespace Users;
    class Nombre extends \Users\GestorUsuarios {
        private $nombre;
        private $longitud;

        public function __contruct($nombre, $longitud){
            //  asdfdsaf
            $this->nombre = $nombre;
            $this->longitud = $longitud;
        }
        public function setNombre($nombre){
            $this->nombre = $nombre;
        }
        public function getNombre(){
            return $this->nombre;
        }
        public function pintar(){
            echo "<input type='text' name='$this->nombre' id='$this->nombre' size='$this->longitud'placeholder='Nombre' value='<?=$this->nombre?>'>";

        }
    }
    

?>