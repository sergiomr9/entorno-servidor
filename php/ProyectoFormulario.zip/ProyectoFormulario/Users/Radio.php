<?php 

    namespace Users;
    class Radio extends \Users\GestorUsuarios {
        private $sexo;
        public function __contruct($sexo){
            //  asdfdsaf
            $this->sexo = $sexo;
        }
        public function setSexo($sexo){
            $this->sexo = $sexo;
        }
        public function getSexo(){
            return $this->sexo;
        }
        public function pintar(){
            echo "<input type='radio' name='$this->sexo' id='$this->sexo' 'placeholder='sexo' value='<?=$this->sexo?>'>";
        }
    }
    

?>