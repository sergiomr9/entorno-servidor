<?php 

    namespace Users;
    class Ciudad extends \Users\GestorUsuarios {
        private $ciudad;
        private $longitud;

        public function __contruct($ciudad, $longitud){
            //  asdfdsaf
            $this->ciudad = $ciudad;
            $this->longitud = $longitud;
        }
        public function setCiudad($ciudad){
            $this->ciudad = $ciudad;
        }
        public function getCiudad(){
            return $this->ciudad;
        }
        public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='text' name='$this->ciudad' id='$this->ciudad' size='$this->longitud'placeholder='ciudad' value='<?=$this->ciudad?>'>";

        }
    }
    

?>