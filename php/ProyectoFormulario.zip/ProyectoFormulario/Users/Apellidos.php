<?php 

    namespace Users;
    class Apellidos extends \Users\GestorUsuarios {
        private $apellidos;
        private $longitud;

        public function __contruct($apellidos, $longitud){
            //  asdfdsaf
            $this->apellidos = $apellidos;
            $this->longitud = $longitud;
        }
        public function setApellidos($apellidos){
            $this->apellidos = $apellidos;
        }
        public function getApellidos(){
            return $this->apellidos;
        }
        public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='text' name='$this->apellidos' id='$this->apellidos' size='$this->longitud'placeholder='apellidos' value='<?=$this->apellidos?>'>";

        }
    }
    

?>