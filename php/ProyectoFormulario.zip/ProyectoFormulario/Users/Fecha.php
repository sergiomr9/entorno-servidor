<?php 

    namespace Users;
    class Fecha extends \Users\GestorUsuarios {
        private $fecha;
        public function __contruct($fecha){
            $this->fecha = $fecha;
        }
        public function setFecha($fecha){
            $this->fecha = $fecha;
        }
        public function getFecha(){
            return $this->fecha;
        }
        public function pintar(){
            echo "<input type='date' name='$this->fecha' id='$this->fecha' 'placeholder='fecha' value='<?=$this->fecha?>'>";
        }
    }
    

?>