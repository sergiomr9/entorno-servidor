<?php 

    namespace Users;
    class Calle extends \Users\GestorUsuarios {
        private $calle;
        private $longitud;

        public function __contruct($calle, $longitud){
            //  asdfdsaf
            $this->calle = $calle;
            $this->longitud = $longitud;
        }
        public function setCalle($calle){
            $this->calle = $calle;
        }
        public function getCalle(){
            return $this->calle;
        }
        public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='text' name='$this->calle' id='$this->calle' size='$this->longitud'placeholder='calle' value='<?=$this->calle?>'>";

        }
    }
    

?>