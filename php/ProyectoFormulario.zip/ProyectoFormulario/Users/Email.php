<?php 

    namespace Users;
    class Email extends \Users\GestorUsuarios {
        private $email;
        public function __contruct($email, $longitud){
            $this->email = $email;
            $this->longitud = $longitud;
        }
        public function setEmail($email){
            $this->email = $email;
        }
        public function getEmail(){
            return $this->email;
        }
        public function pintar(){
            echo "<input type='email' name='$this->email' id='$this->email' size='$this->email'placeholder='email' value='<?=$this->email?>'>";
        }
    }
    

?>