<?php 

    namespace Users;
    class Pais extends \Users\GestorUsuarios {
        private $pais;
        public function __contruct($pais){
            //  asdfdsaf
            $this->pais = $pais;
        }
        public function setPais($pais){
            $this->pais = $pais;
        }
        public function getPais(){
            return $this->pais;
        }
        public function pintar(){
            echo "<input type='text' name='$this->pais' id='$this->pais' size='$this->pais'placeholder='pais' value='<?=$this->pais?>'>";
        }
    }
    

?>