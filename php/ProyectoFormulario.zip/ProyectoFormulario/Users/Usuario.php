<?php 

    namespace Users;
    class Usuario extends \Users\GestorUsuarios {
        private $usuario;
        private $longitud;

        public function __contruct($usuario, $longitud){
            //  asdfdsaf
            $this->usuario = $usuario;
            $this->longitud = $longitud;
        }
        public function setUsuario($usuario){
            $this->usuario = $usuario;
        }
        public function getUsuario(){
            return $this->usuario;
        }
        public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='text' name='$this->usuario' id='$this->usuario' size='$this->longitud'placeholder='usuario' value='<?=$this->usuario?>'>";

        }
    }
    

?>