<?php 

    namespace Users;
    class Piso extends \Users\GestorUsuarios {
        private $piso;
        private $longitud;

        public function __contruct($piso, $longitud){
            //  asdfdsaf
            $this->piso = $piso;
            $this->longitud = $longitud;
        }
        public function setPiso($piso){
            $this->piso = $piso;
        }
        public function getPiso(){
            return $this->piso;
        }
         public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='text' name='$this->piso' id='$this->piso' size='$this->longitud'placeholder='piso' value='<?=$this->piso?>'>";

        }
    }
    

?>