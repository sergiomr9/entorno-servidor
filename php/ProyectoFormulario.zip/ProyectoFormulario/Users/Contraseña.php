<?php 

    namespace Users;
    class Contraseña extends \Users\GestorUsuarios {
        private $contraseña;
        public function __contruct($contraseña, $longitud){
            //  asdfdsaf
            $this->contraseña = $contraseña;
            $this->longitud = $longitud;
        }
        public function setContraseña($contraseña){
            $this->contraseña = $contraseña;
        }
        public function getContraseña(){
            return $this->contraseña;
        }
        public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='password' name='$this->contraseña' id='$this->contraseña' size='$this->contraseña'placeholder='contraseña' value='<?=$this->contraseña?>'>";
        }
    }
    

?>