<?php 

    namespace Users;
    class CodigoPostal extends \Users\GestorUsuarios {
        private $codigoPostal;
        private $longitud;

        public function __contruct($codigoPostal, $longitud){
            //  asdfdsaf
            $this->codigoPostal = $codigoPostal;
            $this->longitud = $longitud;
        }
        public function setCodigoPostal($codigoPostal){
            $this->codigoPostal = $codigoPostal;
        }
        public function getCodigoPostal(){
            return $this->codigoPostal;
        }
        public function setLongitud($longitud){
            $this->longitud = $longitud;
        }
        public function getLongitud(){
            return $this->longitud;
        }
        public function pintar(){
            echo "<input type='text' name='$this->codigoPostal' id='$this->codigoPostal' size='$this->longitud'placeholder='codigoPostal' value='<?=$this->codigoPostal?>'>";

        }
    }
    

?>